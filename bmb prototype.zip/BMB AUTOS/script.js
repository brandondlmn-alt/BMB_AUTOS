const toast = document.getElementById('toast');
const toastMessage = document.getElementById('toastMessage');

function showToast(message) {
    toastMessage.textContent = message;
    toast.classList.remove('hidden');
    toast.classList.add('opacity-100');

    setTimeout(() => {
        toast.classList.add('hidden');
        toast.classList.remove('opacity-100');
    }, 3200);
}

function submitForm(formData) {
    return fetch('process.php', {
        method: 'POST',
        body: formData,
    })
        .then((response) => response.json())
        .catch(() => ({ status: 'error', message: 'Unable to reach server.' }));
}

function handleResponse(data) {
    if (data.status === 'success') {
        showToast(data.message);
    } else {
        showToast(data.message || 'An error occurred.');
    }
}

const mobileMenuButton = document.getElementById('mobileMenuButton');
const mobileMenu = document.getElementById('mobileMenu');
if (mobileMenuButton && mobileMenu) {
    mobileMenuButton.addEventListener('click', () => {
        mobileMenu.classList.toggle('hidden');
    });
}

const purchaseButtons = document.querySelectorAll('.purchaseButton');
purchaseButtons.forEach((button) => {
    button.addEventListener('click', () => {
        const car = JSON.parse(button.dataset.car);
        const formData = new FormData();
        formData.append('action', 'process_transaction');
        formData.append('make', car.make);
        formData.append('model', car.model);
        formData.append('year', car.year);
        formData.append('price', car.price);

        submitForm(formData).then(handleResponse);
    });
});

const serviceForm = document.getElementById('serviceForm');
if (serviceForm) {
    serviceForm.addEventListener('submit', (event) => {
        event.preventDefault();
        const formData = new FormData(serviceForm);
        submitForm(formData).then((data) => {
            handleResponse(data);
            if (data.status === 'success') {
                serviceForm.reset();
            }
        });
    });
}

const loginForm = document.getElementById('loginForm');
if (loginForm) {
    loginForm.addEventListener('submit', (event) => {
        event.preventDefault();
        const formData = new FormData(loginForm);
        submitForm(formData).then((data) => {
            handleResponse(data);
            if (data.status === 'success') {
                setTimeout(() => {
                    window.location.href = 'index.php';
                }, 800);
            }
        });
    });
}

const openModalButton = document.getElementById('openModalButton');
const closeModalButton = document.getElementById('closeModalButton');
const modalOverlay = document.getElementById('modalOverlay');
const vehicleForm = document.getElementById('vehicleForm');

if (openModalButton && closeModalButton && modalOverlay) {
    openModalButton.addEventListener('click', () => {
        modalOverlay.classList.remove('hidden');
    });

    closeModalButton.addEventListener('click', () => {
        modalOverlay.classList.add('hidden');
    });

    modalOverlay.addEventListener('click', (event) => {
        if (event.target === modalOverlay) {
            modalOverlay.classList.add('hidden');
        }
    });
}

if (vehicleForm) {
    vehicleForm.addEventListener('submit', (event) => {
        event.preventDefault();
        const formData = new FormData(vehicleForm);
        submitForm(formData).then((data) => {
            handleResponse(data);
            if (data.status === 'success') {
                vehicleForm.reset();
                modalOverlay.classList.add('hidden');
            }
        });
    });
}
