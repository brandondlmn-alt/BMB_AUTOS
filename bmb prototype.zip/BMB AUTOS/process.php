<?php
header('Content-Type: application/json');

// TODO: Add PDO MySQL Connection here for future database integration.

function CreateBooking($data)
{
    // Placeholder function for booking creation logic.
    $vehicle = htmlspecialchars($data['vehicle'] ?? 'selected vehicle');
    $date = htmlspecialchars($data['date'] ?? 'requested date');
    $time = htmlspecialchars($data['time'] ?? 'requested time');
    $serviceType = htmlspecialchars($data['service_type'] ?? 'service');

    return [
        'status' => 'success',
        'message' => "Booking confirmed for $vehicle on $date at $time for $serviceType.",
    ];
}

function ProcessTransaction($data)
{
    // Placeholder function for transaction processing logic.
    $make = htmlspecialchars($data['make'] ?? 'Vehicle');
    $model = htmlspecialchars($data['model'] ?? 'Purchase');
    $year = htmlspecialchars($data['year'] ?? '');

    return [
        'status' => 'success',
        'message' => "Purchase request received for $year $make $model.",
    ];
}

function AddVehicle($data)
{
    $make = htmlspecialchars($data['make'] ?? 'Unknown');
    $model = htmlspecialchars($data['model'] ?? 'Unknown');
    $year = htmlspecialchars($data['year'] ?? 'Unknown');

    return [
        'status' => 'success',
        'message' => "Vehicle added: $year $make $model.",
    ];
}

function AuthenticateUser($data)
{
    session_start();
    $email = strtolower(trim($data['email'] ?? ''));
    $password = trim($data['password'] ?? '');

    // TODO: Replace this placeholder login check with a secure users table and password hashing.
    if ($email === 'thabo@bmbautos.co.za' && $password === 'welcome123') {
        $_SESSION['user'] = 'Thabo';
        return [
            'status' => 'success',
            'message' => 'Login successful. Redirecting to dashboard...',
        ];
    }

    return [
        'status' => 'error',
        'message' => 'Invalid email or password.',
    ];
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request method.']);
    exit;
}

$action = $_POST['action'] ?? '';
$response = ['status' => 'error', 'message' => 'Action not found.'];

switch ($action) {
    case 'create_booking':
        $response = CreateBooking($_POST);
        break;
    case 'process_transaction':
        $response = ProcessTransaction($_POST);
        break;
    case 'add_vehicle':
        $response = AddVehicle($_POST);
        break;
    case 'login':
        $response = AuthenticateUser($_POST);
        break;
    default:
        $response = ['status' => 'error', 'message' => 'Unknown action specified.'];
        break;
}

echo json_encode($response);
