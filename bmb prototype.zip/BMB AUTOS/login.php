<?php
session_start();
if (isset($_SESSION['user'])) {
    header('Location: index.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BMB Autos | Login</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="min-h-screen bg-slate-50 text-slate-900">
    <main class="flex min-h-screen items-center justify-center px-6 py-12">
        <div class="w-full max-w-xl rounded-[2rem] border border-slate-200 bg-white p-10 shadow-xl">
            <div class="mb-8 text-center">
                <div class="mx-auto mb-5 flex h-16 w-16 items-center justify-center rounded-full bg-blue-600 text-white">B</div>
                <h1 class="text-3xl font-semibold text-slate-900">Sign in to BMB Autos</h1>
                <p class="mt-3 text-slate-600">Use your Thabo credentials to access the customer dashboard.</p>
            </div>

            <form id="loginForm" class="space-y-6">
                <input type="hidden" name="action" value="login">
                <label class="block">
                    <span class="text-sm font-medium text-slate-800">Email</span>
                    <input name="email" type="email" required placeholder="thabo@bmbautos.co.za" class="mt-2 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-slate-900 outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-100" />
                </label>
                <label class="block">
                    <span class="text-sm font-medium text-slate-800">Password</span>
                    <input name="password" type="password" required placeholder="Enter your password" class="mt-2 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-slate-900 outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-100" />
                </label>
                <button type="submit" class="inline-flex w-full items-center justify-center rounded-3xl bg-blue-600 px-6 py-4 text-white shadow hover:bg-blue-500">Login</button>
            </form>

            <div class="mt-6 text-center text-sm text-slate-600">
                <p>Demo credentials: <strong>thabo@bmbautos.co.za / welcome123</strong></p>
            </div>
        </div>
    </main>

    <div id="toast" class="pointer-events-none fixed right-6 top-6 hidden w-80 rounded-3xl border border-slate-200 bg-white p-5 shadow-xl transition duration-300">
        <p id="toastMessage" class="text-sm text-slate-900"></p>
    </div>

    <script src="script.js"></script>
</body>
</html>
