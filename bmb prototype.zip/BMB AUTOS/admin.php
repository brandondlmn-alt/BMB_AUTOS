<?php
session_start();
if (!isset($_SESSION['user'])) {
    header('Location: login.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BMB Autos | Admin Dashboard</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="min-h-screen bg-slate-50 text-slate-900">
    <header class="bg-slate-900 text-white shadow-sm">
        <div class="mx-auto flex max-w-7xl items-center justify-between px-6 py-5">
            <a href="index.php" class="flex items-center gap-3 text-xl font-semibold">
                <span class="inline-flex h-10 w-10 items-center justify-center rounded-full bg-blue-600 text-white">B</span>
                <span>BMB Autos</span>
            </a>
            <nav class="hidden items-center gap-8 md:flex">
                <a href="index.php" class="hover:text-slate-200">Home</a>
                <a href="admin.php" class="text-blue-300 hover:text-white">Admin Dashboard</a>
                <a href="logout.php" class="rounded-full border border-blue-500 px-4 py-2 text-sm font-medium text-blue-100 hover:bg-blue-700">Logout</a>
            </nav>
        </div>
    </header>

    <main class="mx-auto max-w-7xl px-6 py-10">
        <div class="mb-8 flex flex-col gap-4 rounded-3xl bg-white p-8 shadow-xl ring-1 ring-slate-200 sm:flex-row sm:items-center sm:justify-between">
            <div>
                <p class="text-sm uppercase tracking-[0.3em] text-blue-600">Administrator</p>
                <h1 class="mt-3 text-3xl font-semibold text-slate-900">Inventory Management</h1>
                <p class="mt-2 text-slate-600">Monitor stock, status, and add new vehicles quickly.</p>
            </div>
            <button id="openModalButton" class="rounded-3xl bg-blue-600 px-6 py-3 text-white shadow hover:bg-blue-500">Add New Vehicle</button>
        </div>

        <section class="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-slate-200">
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-slate-200 text-left text-sm">
                    <thead class="bg-slate-950 text-white">
                        <tr>
                            <th class="px-6 py-4">CarID</th>
                            <th class="px-6 py-4">Make</th>
                            <th class="px-6 py-4">Model</th>
                            <th class="px-6 py-4">Year</th>
                            <th class="px-6 py-4">Price</th>
                            <th class="px-6 py-4">Status</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-200 bg-white">
                        <tr>
                            <td class="px-6 py-4">001</td>
                            <td class="px-6 py-4">Toyota</td>
                            <td class="px-6 py-4">Corolla</td>
                            <td class="px-6 py-4">2022</td>
                            <td class="px-6 py-4">R 289,900</td>
                            <td class="px-6 py-4 text-green-600">Available</td>
                        </tr>
                        <tr>
                            <td class="px-6 py-4">002</td>
                            <td class="px-6 py-4">Ford</td>
                            <td class="px-6 py-4">EcoSport</td>
                            <td class="px-6 py-4">2021</td>
                            <td class="px-6 py-4">R 489,000</td>
                            <td class="px-6 py-4 text-amber-600">Reserved</td>
                        </tr>
                        <tr>
                            <td class="px-6 py-4">003</td>
                            <td class="px-6 py-4">Audi</td>
                            <td class="px-6 py-4">A3</td>
                            <td class="px-6 py-4">2020</td>
                            <td class="px-6 py-4">R 359,500</td>
                            <td class="px-6 py-4 text-slate-600">Sold</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </section>
    </main>

    <div id="modalOverlay" class="fixed inset-0 z-50 hidden items-center justify-center bg-slate-900/60 px-4 py-6">
        <div class="w-full max-w-2xl rounded-3xl bg-white p-8 shadow-2xl">
            <div class="flex items-center justify-between">
                <div>
                    <h2 class="text-2xl font-semibold text-slate-900">Add New Vehicle</h2>
                    <p class="mt-1 text-sm text-slate-600">Enter the details for the new inventory item.</p>
                </div>
                <button id="closeModalButton" class="rounded-full bg-slate-100 px-3 py-2 text-slate-700 hover:bg-slate-200">✕</button>
            </div>
            <form id="vehicleForm" class="mt-8 grid gap-6">
                <input type="hidden" name="action" value="add_vehicle">
                <label class="block">
                    <span class="text-sm font-medium text-slate-800">Car Make</span>
                    <input name="make" type="text" required class="mt-2 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-slate-900 outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-100" />
                </label>
                <label class="block">
                    <span class="text-sm font-medium text-slate-800">Model</span>
                    <input name="model" type="text" required class="mt-2 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-slate-900 outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-100" />
                </label>
                <label class="block">
                    <span class="text-sm font-medium text-slate-800">Year</span>
                    <input name="year" type="number" min="1990" max="2026" required class="mt-2 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-slate-900 outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-100" />
                </label>
                <label class="block">
                    <span class="text-sm font-medium text-slate-800">Price</span>
                    <input name="price" type="text" required class="mt-2 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-slate-900 outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-100" placeholder="R 0.00" />
                </label>
                <label class="block">
                    <span class="text-sm font-medium text-slate-800">Status</span>
                    <select name="status" required class="mt-2 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-slate-900 outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-100">
                        <option value="Available">Available</option>
                        <option value="Reserved">Reserved</option>
                        <option value="Sold">Sold</option>
                    </select>
                </label>
                <button type="submit" class="inline-flex w-full items-center justify-center rounded-3xl bg-blue-600 px-6 py-4 text-white shadow hover:bg-blue-500">Save Vehicle</button>
            </form>
        </div>
    </div>

    <div id="toast" class="pointer-events-none fixed right-6 top-6 hidden w-80 rounded-3xl border border-slate-200 bg-white p-5 shadow-xl transition duration-300">
        <p id="toastMessage" class="text-sm text-slate-900"></p>
    </div>

    <script src="script.js"></script>
</body>
</html>
