<?php
session_start();
if (!isset($_SESSION['user'])) {
    header('Location: login.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BMB Autos | Customer Dashboard</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="min-h-screen bg-slate-50 text-slate-900">
    <header class="bg-slate-900 text-white shadow-sm">
        <div class="mx-auto flex max-w-7xl items-center justify-between px-6 py-5">
            <a href="index.php" class="flex items-center gap-3 text-xl font-semibold">
                <span class="inline-flex h-10 w-10 items-center justify-center rounded-full bg-blue-600 text-white">B</span>
                <span>BMB Autos</span>
            </a>
            <nav class="hidden items-center gap-8 md:flex">
                <a href="index.php" class="hover:text-slate-200">Home</a>
                <a href="#browse" class="hover:text-slate-200">Browse Cars</a>
                <a href="#service" class="hover:text-slate-200">Book Service</a>
                <a href="admin.php" class="rounded-full bg-blue-600 px-4 py-2 text-sm font-medium text-white shadow hover:bg-blue-500">Admin Dashboard</a>
                <a href="login.php" class="rounded-full border border-blue-500 px-4 py-2 text-sm font-medium text-blue-100 hover:bg-blue-700">Login</a>
            </nav>
            <button id="mobileMenuButton" class="inline-flex items-center justify-center rounded-lg border border-slate-700 bg-slate-800 p-2 text-slate-100 md:hidden">
                <span class="sr-only">Open menu</span>
                <svg class="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"></path></svg>
            </button>
        </div>
        <div id="mobileMenu" class="hidden border-t border-slate-700 bg-slate-950 px-6 py-4 md:hidden">
            <a href="index.php" class="block py-2 text-slate-100">Home</a>
            <a href="#browse" class="block py-2 text-slate-100">Browse Cars</a>
            <a href="#service" class="block py-2 text-slate-100">Book Service</a>
            <a href="admin.php" class="block rounded-full bg-blue-600 px-4 py-2 text-center text-white">Admin Dashboard</a>
            <a href="login.php" class="block py-2 text-slate-100">Login</a>
        </div>
    </header>

    <main class="mx-auto max-w-7xl px-6 py-10">
        <section class="rounded-3xl bg-white p-8 shadow-xl ring-1 ring-slate-200">
            <div class="flex flex-col gap-6 lg:flex-row lg:items-center lg:justify-between">
                <div>
                    <p class="text-sm uppercase tracking-[0.3em] text-blue-600">Welcome to BMB Autos</p>
                    <h1 class="mt-3 text-4xl font-semibold text-slate-900">Welcome back, Thabo</h1>
                    <p class="mt-3 max-w-2xl text-slate-600">Buy it. Service it. Maintain it. Explore quality certified used vehicles and book trusted servicing in one place.</p>
                </div>
                <div class="grid grid-cols-1 gap-3 sm:grid-cols-3">
                    <a href="#browse" class="rounded-3xl bg-slate-900 px-5 py-4 text-center text-white shadow hover:bg-slate-800">Browse Cars</a>
                    <a href="#service" class="rounded-3xl bg-blue-600 px-5 py-4 text-center text-white shadow hover:bg-blue-500">Service Booking</a>
                    <button class="rounded-3xl border border-slate-200 bg-white px-5 py-4 text-center text-slate-900 shadow hover:border-slate-300">My Trade-Ins</button>
                </div>
            </div>
        </section>

        <section class="mt-10">
            <div class="flex items-center justify-between">
                <div>
                    <h2 class="text-2xl font-semibold text-slate-900">Recommended for You</h2>
                    <p class="mt-2 text-slate-600">Premium selections tailored to your driving style.</p>
                </div>
            </div>
            <div class="mt-6 grid gap-5 md:grid-cols-3">
                <article class="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-slate-200">
                    <p class="text-sm uppercase tracking-[0.25em] text-blue-600">Family Sedan</p>
                    <h3 class="mt-4 text-xl font-semibold text-slate-900">Honda Civic LX</h3>
                    <p class="mt-2 text-slate-600">Comfort, fuel efficiency, and dependable ownership.</p>
                    <div class="mt-5 space-y-2 text-sm text-slate-700">
                        <p><strong>Year:</strong> 2021</p>
                        <p><strong>Mileage:</strong> 34,000 km</p>
                        <p><strong>Transmission:</strong> Automatic</p>
                    </div>
                </article>
                <article class="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-slate-200">
                    <p class="text-sm uppercase tracking-[0.25em] text-blue-600">Luxury Compact</p>
                    <h3 class="mt-4 text-xl font-semibold text-slate-900">BMW 320i</h3>
                    <p class="mt-2 text-slate-600">Dynamic performance with premium comfort.</p>
                    <div class="mt-5 space-y-2 text-sm text-slate-700">
                        <p><strong>Year:</strong> 2019</p>
                        <p><strong>Mileage:</strong> 48,500 km</p>
                        <p><strong>Fuel:</strong> Petrol</p>
                    </div>
                </article>
                <article class="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-slate-200">
                    <p class="text-sm uppercase tracking-[0.25em] text-blue-600">Adventure Ready</p>
                    <h3 class="mt-4 text-xl font-semibold text-slate-900">Toyota Fortuner</h3>
                    <p class="mt-2 text-slate-600">Roomy, rugged, and ready for every journey.</p>
                    <div class="mt-5 space-y-2 text-sm text-slate-700">
                        <p><strong>Year:</strong> 2020</p>
                        <p><strong>Transmission:</strong> Automatic</p>
                        <p><strong>Price:</strong> R 649,000</p>
                    </div>
                </article>
            </div>
        </section>

        <section id="browse" class="mt-12">
            <div class="flex items-center justify-between">
                <div>
                    <h2 class="text-2xl font-semibold text-slate-900">Browse Cars</h2>
                    <p class="mt-2 text-slate-600">Choose from our top available inventory.</p>
                </div>
            </div>
            <div class="mt-8 grid gap-6 lg:grid-cols-3">
                <div class="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-slate-200">
                    <div class="flex items-center justify-between">
                        <span class="rounded-full bg-blue-50 px-3 py-1 text-xs font-semibold uppercase tracking-[0.25em] text-blue-700">Sedan</span>
                        <span class="text-xl font-semibold text-slate-900">R 289,900</span>
                    </div>
                    <h3 class="mt-4 text-2xl font-semibold text-slate-900">Toyota Corolla</h3>
                    <p class="mt-2 text-slate-600">Reliable, efficient, and perfect for daily driving.</p>
                    <ul class="mt-6 space-y-2 text-sm text-slate-700">
                        <li><strong>Year:</strong> 2022</li>
                        <li><strong>Mileage:</strong> 28,500 km</li>
                        <li><strong>Transmission:</strong> Automatic</li>
                        <li><strong>Fuel:</strong> Petrol</li>
                    </ul>
                    <button data-car='{"make":"Toyota","model":"Corolla","year":"2022","price":"R 289,900"}' class="purchaseButton mt-6 w-full rounded-2xl bg-blue-600 px-5 py-3 text-white transition hover:bg-blue-500">Purchase</button>
                </div>

                <div class="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-slate-200">
                    <div class="flex items-center justify-between">
                        <span class="rounded-full bg-blue-50 px-3 py-1 text-xs font-semibold uppercase tracking-[0.25em] text-blue-700">SUV</span>
                        <span class="text-xl font-semibold text-slate-900">R 489,000</span>
                    </div>
                    <h3 class="mt-4 text-2xl font-semibold text-slate-900">Ford EcoSport</h3>
                    <p class="mt-2 text-slate-600">Compact SUV with strong value and city-ready agility.</p>
                    <ul class="mt-6 space-y-2 text-sm text-slate-700">
                        <li><strong>Year:</strong> 2021</li>
                        <li><strong>Mileage:</strong> 39,200 km</li>
                        <li><strong>Transmission:</strong> Automatic</li>
                        <li><strong>Fuel:</strong> Petrol</li>
                    </ul>
                    <button data-car='{"make":"Ford","model":"EcoSport","year":"2021","price":"R 489,000"}' class="purchaseButton mt-6 w-full rounded-2xl bg-blue-600 px-5 py-3 text-white transition hover:bg-blue-500">Purchase</button>
                </div>

                <div class="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-slate-200">
                    <div class="flex items-center justify-between">
                        <span class="rounded-full bg-blue-50 px-3 py-1 text-xs font-semibold uppercase tracking-[0.25em] text-blue-700">Coupe</span>
                        <span class="text-xl font-semibold text-slate-900">R 359,500</span>
                    </div>
                    <h3 class="mt-4 text-2xl font-semibold text-slate-900">Audi A3</h3>
                    <p class="mt-2 text-slate-600">Sporty, luxurious, and designed for refined driving.</p>
                    <ul class="mt-6 space-y-2 text-sm text-slate-700">
                        <li><strong>Year:</strong> 2020</li>
                        <li><strong>Mileage:</strong> 44,000 km</li>
                        <li><strong>Transmission:</strong> Automatic</li>
                        <li><strong>Fuel:</strong> Petrol</li>
                    </ul>
                    <button data-car='{"make":"Audi","model":"A3","year":"2020","price":"R 359,500"}' class="purchaseButton mt-6 w-full rounded-2xl bg-blue-600 px-5 py-3 text-white transition hover:bg-blue-500">Purchase</button>
                </div>
            </div>
        </section>

        <section id="service" class="mt-12 rounded-3xl bg-white p-8 shadow-xl ring-1 ring-slate-200">
            <div class="flex items-center justify-between">
                <div>
                    <h2 class="text-2xl font-semibold text-slate-900">Book a Service</h2>
                    <p class="mt-2 text-slate-600">Schedule maintenance with our certified technicians.</p>
                </div>
            </div>
            <form id="serviceForm" class="mt-8 grid gap-6 lg:grid-cols-2">
                <label class="block">
                    <span class="text-sm font-medium text-slate-800">Select Vehicle</span>
                    <select name="vehicle" required class="mt-2 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-slate-900 outline-none transition focus:border-blue-500 focus:ring-2 focus:ring-blue-100">
                        <option value="Toyota Corolla 2022">Toyota Corolla 2022</option>
                        <option value="Ford EcoSport 2021">Ford EcoSport 2021</option>
                        <option value="Audi A3 2020">Audi A3 2020</option>
                    </select>
                </label>

                <label class="block">
                    <span class="text-sm font-medium text-slate-800">Preferred Date</span>
                    <input name="date" type="date" required class="mt-2 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-slate-900 outline-none transition focus:border-blue-500 focus:ring-2 focus:ring-blue-100" />
                </label>

                <label class="block">
                    <span class="text-sm font-medium text-slate-800">Preferred Time</span>
                    <input name="time" type="time" required class="mt-2 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-slate-900 outline-none transition focus:border-blue-500 focus:ring-2 focus:ring-blue-100" />
                </label>

                <label class="block">
                    <span class="text-sm font-medium text-slate-800">Service Type</span>
                    <select name="service_type" required class="mt-2 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-slate-900 outline-none transition focus:border-blue-500 focus:ring-2 focus:ring-blue-100">
                        <option value="Oil Change">Oil Change</option>
                        <option value="Full Service">Full Service</option>
                        <option value="Brake Inspection">Brake Inspection</option>
                    </select>
                </label>

                <div class="lg:col-span-2">
                    <input type="hidden" name="action" value="create_booking">
                    <button type="submit" class="inline-flex w-full items-center justify-center rounded-3xl bg-blue-600 px-6 py-4 text-white shadow hover:bg-blue-500">Confirm Service Booking</button>
                </div>
            </form>
        </section>
    </main>

    <div id="toast" class="pointer-events-none fixed right-6 top-6 hidden w-80 rounded-3xl border border-slate-200 bg-white p-5 shadow-xl transition duration-300">
        <p id="toastMessage" class="text-sm text-slate-900"></p>
    </div>

    <script src="script.js"></script>
</body>
</html>
